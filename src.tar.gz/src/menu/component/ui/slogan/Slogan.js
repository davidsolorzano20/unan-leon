import React, { Component } from 'react'

export default class Slogan extends Component {
	render () {
		return (
			<span className={'slogan'}>A la Libertad por la Universidad</span>
		)
	}
}
