import React from 'react';
import * as firebase from 'firebase';
import tar from 'tar';
import fs from 'fs-extra';
import { remote } from "electron"
const fetch = remote.require('electron-fetch');

export default class ServerApi {

	static Version() {
		let version = '1.1.0-alpha';
		const db = firebase.database()
		const version_app = db.ref().child('version');
		version_app.on('value', snap => {
			 version = snap.val();
		});
	}

	static UpdateApp() {
		try {
			const UpdateDirectory = path.join(app.getPath('userData'), 'version');

			const UpdateTempDirectory = path.join(UpdateDirectory, 'temp');
			const archivePath = path.join(UpdateTempDirectory, 'version.tar.gz');
			const packageUrl = `${SERVER_URL}/${API_VERSION}/recipes/${recipeId}/recipe_download`;

			fs.ensureDirSync(UpdateTempDirectory);
			const res = fetch(packageUrl);
			console.debug('Update downloaded');
			const buffer = res.buffer();
			fs.writeFileSync(archivePath, buffer);

			sleep(10);

			tar.x({
				file: archivePath,
				cwd: UpdateTempDirectory,
				preservePaths: true,
				unlink: true,
				preserveOwner: false,
				onwarn: x => console.log('warn', 'app', x),
			});

			sleep(10);

			const newVersion = path.join(UpdateDirectory, 'app');
			fs.copySync(UpdateTempDirectory+'/app', newVersion);
			fs.remove(UpdateTempDirectory);
			fs.remove(path.join(UpdateDirectory, 'app', 'version.tar.gz'));

			return 'app';
		} catch (err) {
			console.error(err);
			return false;
		}
	}

}
