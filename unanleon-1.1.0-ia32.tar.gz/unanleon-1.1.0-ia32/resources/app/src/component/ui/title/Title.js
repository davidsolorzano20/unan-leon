import React, { Component } from 'react'

export default class Title extends Component {
	render () {
		return (
			<div className="title m-b-md">
				Bienvenido a UNAN-Le&oacute;n
			</div>
		)
	}
}
